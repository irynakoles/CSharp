﻿using System;


namespace Lesson_4Test
{
    class Program
    {
        static void Main(string[] args)
        {
           

        }

    }
}
        

        
     