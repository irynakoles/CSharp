﻿using System;


namespace Lesson_4Test
{
    class ArrayInitializator
    {
        //Input array size
        static int ReadArraySize()
        {
            string userInput;
            int arraySize;
            Console.WriteLine("Please, enter size of array. ");
            userInput = Console.ReadLine();
            if (!Int32.TryParse(userInput, out arraySize))
            {
                Console.WriteLine("Please, Enter the correct number");
                Console.ReadKey();
                return -1;

            }
            return arraySize;
        }
        //Fill the array
        static int[] ReadArrayNumbers(int arraySize)
        {

            int[] array = new int[arraySize];

            Console.WriteLine("Please, enter the numbers to array.");
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = int.Parse(Console.ReadLine());

            }
            return array;
        }
    }
}
